# AralMe Common Backend Code


## Usage

To test the changes made in this library against services 
```
$ npm run inject --path=<Your service location>
```
eg. 
```
$ npm run inject --path=../aralme-user-service
```
**WARNING!!**

*Please use the above approach **only** for local testing. Make sure that you still push your changes from here, and update the version in the target service as mentioned below* 


To use this library in a service, make sure that you are pointing to aralme npm feed,
```
$ cat .npmrc
registry=https://pkgs.dev.azure.com/bp-vsts/BPme/_packaging/aralme/npm/registry/
always-auth=true
```

For installation,

```
$ npm install @bp/bp-mfe-common-backend
```

## Contribution

For contribution, please update update `lib/` folder, add necessary tests to `test/` and push and merge to `main` branch.

Publish will happen only from `main` branch.

## Known issues

- Version needs to be manually incremented before merging to main, publish will fail otherwise.
- [loglevel](https://www.npmjs.com/package/loglevel) is used to set logging levels.  ERROR, WARN, INFO, TRACE, DEBUG are the logging levels.   
There is a known [issue](https://github.com/pimterry/loglevel/issues/137) in loglevel because of which debug logs are printed as info logs in AWS Cloudwatch.   
To fix the issue we have overridden the default behaviour of debug method in loglevel using the [plugins](https://www.npmjs.com/package/loglevel#plugins) feature as mentioned in the issue  
  
   