/**
 * Returns just an AMI ID
 */
export declare type AmiContextResponse = string;
