import * as cxschema from '@aws-cdk/cloud-assembly-schema';
import { CloudArtifact } from '../cloud-artifact';
import { CloudAssembly } from '../cloud-assembly';
/**
 * @stability stable
 */
export declare class TreeCloudArtifact extends CloudArtifact {
    /**
     * @stability stable
     */
    readonly file: string;
    /**
     * @stability stable
     */
    constructor(assembly: CloudAssembly, name: string, artifact: cxschema.ArtifactManifest);
}
