## Cloud Assembly JSON Schema

**DO NOT MODIFY FILES IN THIS DIRECTORY BY HAND**

To modify, run `yarn update-schema`.