/**
 * Possible values for a resource's Removal Policy.
 *
 * The removal policy controls what happens to the resource if it stops being
 * managed by CloudFormation. This can happen in one of three situations:
 *
 * - The resource is removed from the template, so CloudFormation stops managing it;
 * - A change to the resource is made that requires it to be replaced, so CloudFormation stops
 *    managing it;
 * - The stack is deleted, so CloudFormation stops managing all resources in it.
 *
 * The Removal Policy applies to all above cases.
 *
 * Many stateful resources in the AWS Construct Library will accept a
 * `removalPolicy` as a property, typically defaulting it to `RETAIN`.
 *
 * If the AWS Construct Library resource does not accept a `removalPolicy`
 * argument, you can always configure it by using the escape hatch mechanism,
 * as shown in the following example:
 *
 * ```ts
 * const cfnBucket = bucket.node.findChild('Resource') as cdk.CfnResource;
 * cfnBucket.applyRemovalPolicy(cdk.RemovalPolicy.DESTROY);
 * ```
 *
 * @stability stable
 */
export declare enum RemovalPolicy {
    /**
     * This is the default removal policy.
     *
     * It means that when the resource is
     * removed from the app, it will be physically destroyed.
     *
     * @stability stable
     */
    DESTROY = "destroy",
    /**
     * This uses the 'Retain' DeletionPolicy, which will cause the resource to be retained in the account, but orphaned from the stack.
     *
     * @stability stable
     */
    RETAIN = "retain",
    /**
     * This retention policy deletes the resource, but saves a snapshot of its data before deleting, so that it can be re-created later.
     *
     * Only available for some stateful resources,
     * like databases, EFS volumes, etc.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-deletionpolicy.html#aws-attribute-deletionpolicy-options
     * @stability stable
     */
    SNAPSHOT = "snapshot"
}
/**
 * @stability stable
 */
export interface RemovalPolicyOptions {
    /**
     * The default policy to apply in case the removal policy is not defined.
     *
     * @default - Default value is resource specific. To determine the default value for a resoure,
     * please consult that specific resource's documentation.
     * @stability stable
     */
    readonly default?: RemovalPolicy;
    /**
     * Apply the same deletion policy to the resource's "UpdateReplacePolicy".
     *
     * @default true
     * @stability stable
     */
    readonly applyToUpdateReplacePolicy?: boolean;
}
