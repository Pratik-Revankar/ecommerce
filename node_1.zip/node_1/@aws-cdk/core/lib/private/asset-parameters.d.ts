import { CfnParameter } from '../cfn-parameter';
import { Construct } from '../construct-compat';
export declare class FileAssetParameters extends Construct {
    readonly bucketNameParameter: CfnParameter;
    readonly objectKeyParameter: CfnParameter;
    readonly artifactHashParameter: CfnParameter;
    constructor(scope: Construct, id: string);
}
