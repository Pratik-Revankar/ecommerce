import { IConstruct } from './construct-compat';
/**
 * Trait marker for classes that can be depended upon.
 *
 * The presence of this interface indicates that an object has
 * an `IDependableTrait` implementation.
 *
 * This interface can be used to take an (ordering) dependency on a set of
 * constructs. An ordering dependency implies that the resources represented by
 * those constructs are deployed before the resources depending ON them are
 * deployed.
 *
 * @stability stable
 */
export interface IDependable {
}
/**
 * A set of constructs to be used as a dependable.
 *
 * This class can be used when a set of constructs which are disjoint in the
 * construct tree needs to be combined to be used as a single dependable.
 *
 * @stability stable
 */
export declare class ConcreteDependable implements IDependable {
    private readonly _dependencyRoots;
    /**
     * @stability stable
     */
    constructor();
    /**
     * Add a construct to the dependency roots.
     *
     * @stability stable
     */
    add(construct: IConstruct): void;
}
/**
 * Trait for IDependable.
 *
 * Traits are interfaces that are privately implemented by objects. Instead of
 * showing up in the public interface of a class, they need to be queried
 * explicitly. This is used to implement certain framework features that are
 * not intended to be used by Construct consumers, and so should be hidden
 * from accidental use.
 *
 * @stability stable
 * @example
 *
 * // Usage
 * const roots = DependableTrait.get(construct).dependencyRoots;
 *
 * // Definition
 * class TraitImplementation implements DependableTrait {
 *   public readonly dependencyRoots: IConstruct[];
 *   constructor() {
 *     this.dependencyRoots = [constructA, constructB, constructC];
 *   }
 * }
 * DependableTrait.implement(construct, new TraitImplementation());
 */
export declare abstract class DependableTrait {
    /**
     * Register `instance` to have the given DependableTrait.
     *
     * Should be called in the class constructor.
     *
     * @stability stable
     */
    static implement(instance: IDependable, trait: DependableTrait): void;
    /**
     * Return the matching DependableTrait for the given class instance.
     *
     * @stability stable
     */
    static get(instance: IDependable): DependableTrait;
    /**
     * The set of constructs that form the root of this dependable.
     *
     * All resources under all returned constructs are included in the ordering
     * dependency.
     *
     * @stability stable
     */
    abstract readonly dependencyRoots: IConstruct[];
}
