import { IConstruct } from './construct-compat';
import { TokenizedStringFragments } from './string-fragments';
/**
 * Current resolution context for tokens.
 *
 * @stability stable
 */
export interface IResolveContext {
    /**
     * The scope from which resolution has been initiated.
     *
     * @stability stable
     */
    readonly scope: IConstruct;
    /**
     * True when we are still preparing, false if we're rendering the final output.
     *
     * @stability stable
     */
    readonly preparing: boolean;
    /**
     * Resolve an inner object.
     *
     * @stability stable
     */
    resolve(x: any, options?: ResolveChangeContextOptions): any;
    /**
     * Use this postprocessor after the entire token structure has been resolved.
     *
     * @stability stable
     */
    registerPostProcessor(postProcessor: IPostProcessor): void;
}
/**
 * Options that can be changed while doing a recursive resolve.
 *
 * @stability stable
 */
export interface ResolveChangeContextOptions {
    /**
     * Change the 'allowIntrinsicKeys' option.
     *
     * @default - Unchanged
     * @stability stable
     */
    readonly allowIntrinsicKeys?: boolean;
}
/**
 * Interface for values that can be resolvable later.
 *
 * Tokens are special objects that participate in synthesis.
 *
 * @stability stable
 */
export interface IResolvable {
    /**
     * The creation stack of this resolvable which will be appended to errors thrown during resolution.
     *
     * This may return an array with a single informational element indicating how
     * to get this property populated, if it was skipped for performance reasons.
     *
     * @stability stable
     */
    readonly creationStack: string[];
    /**
     * Produce the Token's value at resolution time.
     *
     * @stability stable
     */
    resolve(context: IResolveContext): any;
    /**
     * Return a string representation of this resolvable object.
     *
     * Returns a reversible string representation.
     *
     * @stability stable
     */
    toString(): string;
}
/**
 * A Token that can post-process the complete resolved value, after resolve() has recursed over it.
 *
 * @stability stable
 */
export interface IPostProcessor {
    /**
     * Process the completely resolved value, after full recursion/resolution has happened.
     *
     * @stability stable
     */
    postProcess(input: any, context: IResolveContext): any;
}
/**
 * How to resolve tokens.
 *
 * @stability stable
 */
export interface ITokenResolver {
    /**
     * Resolve a single token.
     *
     * @stability stable
     */
    resolveToken(t: IResolvable, context: IResolveContext, postProcessor: IPostProcessor): any;
    /**
     * Resolve a string with at least one stringified token in it.
     *
     * (May use concatenation)
     *
     * @stability stable
     */
    resolveString(s: TokenizedStringFragments, context: IResolveContext): any;
    /**
     * Resolve a tokenized list.
     *
     * @stability stable
     */
    resolveList(l: string[], context: IResolveContext): any;
}
/**
 * Function used to concatenate symbols in the target document language.
 *
 * Interface so it could potentially be exposed over jsii.
 *
 * @stability stable
 */
export interface IFragmentConcatenator {
    /**
     * Join the fragment on the left and on the right.
     *
     * @stability stable
     */
    join(left: any | undefined, right: any | undefined): any;
}
/**
 * Converts all fragments to strings and concats those.
 *
 * Drops 'undefined's.
 *
 * @stability stable
 */
export declare class StringConcat implements IFragmentConcatenator {
    /**
     * Join the fragment on the left and on the right.
     *
     * @stability stable
     */
    join(left: any | undefined, right: any | undefined): any;
}
/**
 * Default resolver implementation.
 *
 * @stability stable
 */
export declare class DefaultTokenResolver implements ITokenResolver {
    private readonly concat;
    /**
     * @stability stable
     */
    constructor(concat: IFragmentConcatenator);
    /**
     * Default Token resolution.
     *
     * Resolve the Token, recurse into whatever it returns,
     * then finally post-process it.
     *
     * @stability stable
     */
    resolveToken(t: IResolvable, context: IResolveContext, postProcessor: IPostProcessor): any;
    /**
     * Resolve string fragments to Tokens.
     *
     * @stability stable
     */
    resolveString(fragments: TokenizedStringFragments, context: IResolveContext): any;
    /**
     * Resolve a tokenized list.
     *
     * @stability stable
     */
    resolveList(xs: string[], context: IResolveContext): any;
}
