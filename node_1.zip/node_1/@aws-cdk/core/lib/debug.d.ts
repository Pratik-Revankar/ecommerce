export declare const CDK_DEBUG = "CDK_DEBUG";
export declare function debugModeEnabled(): boolean;
