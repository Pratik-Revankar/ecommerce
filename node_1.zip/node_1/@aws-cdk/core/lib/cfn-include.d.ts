import { Construct } from 'constructs';
import { CfnElement } from './cfn-element';
/**
 * (deprecated) Construction properties for {@link CfnInclude}.
 *
 * @deprecated use the CfnInclude class from the cloudformation-include module instead
 */
export interface CfnIncludeProps {
    /**
     * (deprecated) The CloudFormation template to include in the stack (as is).
     *
     * @deprecated
     */
    readonly template: object;
}
/**
 * (deprecated) Includes a CloudFormation template into a stack.
 *
 * All elements of the template will be merged into
 * the current stack, together with any elements created programmatically.
 *
 * @deprecated use the CfnInclude class from the cloudformation-include module instead
 */
export declare class CfnInclude extends CfnElement {
    /**
     * (deprecated) The included template.
     *
     * @deprecated
     */
    readonly template: object;
    /**
     * (deprecated) Creates an adopted template construct.
     *
     * The template will be incorporated into the stack as-is with no changes at all.
     * This means that logical IDs of entities within this template may conflict with logical IDs of entities that are part of the
     * stack.
     *
     * @param scope The parent construct of this template.
     * @param id The ID of this construct.
     * @param props Initialization properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnIncludeProps);
    /**
     * @internal
     */
    _toCloudFormation(): object;
}
