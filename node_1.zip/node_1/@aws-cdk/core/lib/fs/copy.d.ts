import { CopyOptions } from './options';
export declare function copyDirectory(srcDir: string, destDir: string, options?: CopyOptions, rootDir?: string): void;
