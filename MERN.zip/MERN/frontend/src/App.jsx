import React, { useState } from "react";
import Header from "./components/Header";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Cart from "./components/Cart";
import Wishlist from "./components/Wishlist";
import Profile from "./components/Profile";
import Home from "./components/Home";
import Product from "./pages/Product";
import SignUp from "./components/SignUp";
import SignIn from "./components/SignIn";
import ProductCard from "./components/ProductCard";
import Products from "./pages/Products";
import Address from "./components/Address";
import Checkout from "./pages/Checkout";
import Data from "./pages/Data";
import StripeCheckout from "./pages/StripeCheckout";
import MobileNav from "./components/MobileNav";
import Orders from "./components/Orders";
import ProfileInfo from "./components/ProfileInfo";
import Login from "./pages/Login";
import SideNav from "./components/SideNav";

const App = () => {
  const categories = [
    "Home",
    "smartphone",
    "Men's",
    "Women's",
    "Jewelry",
    "Perfume",
    "Blog",
    "Hot Offers",
  ];
  const [search, setSearch] = useState("");
  const [toggle, setToggle] = useState("");
  const [isChecked, setIsChecked] = useState();
  return (
    <div className="font-mono max-w-5xl m-auto">
      <BrowserRouter>
        <Header search={search} setSearch={setSearch} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/wishlist" element={<Wishlist />} />
          {/* <Route path="/wishlist" element={<Wishlist />} /> */}
          {/* <Route path="/profile" element={<Profile />} /> */}
          {/* <Route path="/signup" element={<SignUp />} /> */}
          <Route path="/login" element={<Login />} />

          <Route path="/products/:category" element={<Products />} />
          <Route path="/product/details" element={<Product />} />
          <Route
            path="/checkout"
            element={
              <Checkout isChecked={isChecked} setIsChecked={setIsChecked} />
            }
          />
          <Route path="/stripe-checkout" element={<StripeCheckout />} />

          <Route path="/strip" element={<Data />} />
          <Route path="/orders" element={<Orders />} />
          <Route
            path="/myprofile"
            element={
              <ProfileInfo isChecked={isChecked} setIsChecked={setIsChecked} />
            }
          />
        </Routes>
        <SideNav
          toggle={toggle}
          setToggle={setToggle}
          categories={categories}
        />
        <div className="hidden max-sm:block">
          <MobileNav toggle={toggle} setToggle={setToggle} />
        </div>
      </BrowserRouter>
    </div>
  );
};

export default App;
