import React, { useEffect, useState } from "react";
import SignUp from "../components/SignUp";
import SignIn from "../components/SignIn";
import { useSelector } from "react-redux";
import { message, userToken } from "../slice/auth/authSlice";
import { useNavigate } from "react-router";
import Cookies from "universal-cookie";
const Login = () => {
  const [toggle, setToggle] = useState(false);
  const msg = useSelector(message);
  const token = useSelector(userToken);
  const cookie = new Cookies();
  console.log(cookie);
  const navigate = useNavigate();

  const [firstName, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  useEffect(() => {
    if (token) {
      navigate("/");
    }
  }, [token]);
  return (
    <div>
      {toggle ? (
        <SignUp
          firstName={firstName}
          email={email}
          password={password}
          setName={setName}
          setEmail={setEmail}
          setPassword={setPassword}
          toggle={toggle}
          setToggle={setToggle}
        />
      ) : (
        <SignIn
          email={email}
          password={password}
          setEmail={setEmail}
          setPassword={setPassword}
          toggle={toggle}
          setToggle={setToggle}
        />
      )}

      <div> {msg && <div>{msg}</div>}</div>
      {/* {token && navigate("/")} */}
    </div>
  );
};

export default Login;
