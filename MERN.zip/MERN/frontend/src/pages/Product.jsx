import React, { useEffect, useLayoutEffect, useState } from "react";
import Jacket from "../assets/images/jacket-1.jpg";
import Button from "../components/Button";
import { loading, productDetails } from "../slice/product/productSlice";
import { useDispatch, useSelector } from "react-redux";
import { addCartItemAsync, cartItem } from "../slice/cart/cartSlice";
import { useNavigate } from "react-router";
import { buyNow } from "../slice/checkout/checkoutSlice";

const Product = () => {
  const [btnText, setBtnText] = useState("add to cart");

  const loader = useSelector(loading);

  const product = useSelector((state) => {
    if (!state.product.loading) {
      return state.product.productDetails;
    }
  });
  const navigate = useNavigate();

  const cartItems = useSelector(cartItem);
  // console.log(product);
  const dispatch = useDispatch();

  useEffect(() => {
    cartItems.map((item) => {
      if (product) {
        if (item.product._id === product._id) {
          setBtnText("Go to Cart");
          return;
        }
      }
    });
  }, [product]);

  const handleAddtoCart = () => {
    if (
      cartItems.findIndex((item) => {
        return item.product._id === product._id;
      }) < 0
    ) {
      dispatch(addCartItemAsync({ product: product._id, quantity: 1 }));

      setBtnText("Go to Cart");
    } else {
      navigate("/cart");
    }
  };

  const handleBuyNow = () => {
    dispatch(buyNow([{ product, quantity: 1 }]));
    navigate("/checkout");
  };

  return (
    <>
      {!loader && product && (
        <div className="font-poppins max-w-5xl mt-12 m-auto">
          <div className="flex justify-center">
            <div className=" w-[450px]">
              <img src={product.image[0].public_url} alt="" />
            </div>
            <div className="w-[40%] p-8 ">
              <div>
                <h3>{product.brand}</h3>
                <p className="mb-3">{product.title}</p>
                <div className="flex gap-2">
                  <p>{product.price}</p>
                  <del>$120</del>
                </div>
                <p>⭐⭐⭐</p>
                <div className="my-4 flex gap-4">
                  <div onClick={handleAddtoCart}>
                    <Button value={btnText} />
                  </div>
                  <div onClick={handleBuyNow}>
                    <Button value="Buy now" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Product;
