import React, { useEffect, useState } from "react";
import ProductCard from "../components/ProductCard";
import CategorySection from "../components/CategorySection";
import {
  brand,
  getBrandsByCategoryAsync,
  getProductsAsync,
  product,
} from "../slice/product/productSlice";
import { useDispatch, useSelector } from "react-redux";
import Brands from "../components/Brands";
import { useParams } from "react-router";
import Card from "../components/Card";
import Price from "../components/Price";

const Products = () => {
  const params = useParams();
  const dispatch = useDispatch();
  const [selectedBrand, setSelectedBrand] = useState([]);
  // console.log(selectedBrand);
  useEffect(() => {
    if (params.category) {
      dispatch(
        getProductsAsync({
          category: params.category,
          brand: "",
          keyword: "",
        })
      );
    }
    dispatch(getBrandsByCategoryAsync(params.category));
  }, [brand]);

  const products = useSelector(product);
  const brands = useSelector(brand);

  return (
    <div className="max-w-[1024px] m-auto bg-gray-100">
      <div className="flex justify-center pt-5 gap-2 px-5 max-sm:block">
        <div className="w-[20%] max-sm:w-[80%] mx-auto">
          {brands.length > 0 && (
            <div className="mt-4">
              {/* <CategorySection /> */}
              <Brands
                category={params.category}
                selectedBrand={selectedBrand}
                setSelectedBrand={setSelectedBrand}
              />
              {/* <CategorySection /> */}
              <Price category={params.category} selectedBrand={selectedBrand} />
            </div>
          )}
        </div>
        <div className="w-full m-auto">
          {/* <ProductCard /> */}
          <Card />
        </div>
      </div>
    </div>
  );
};

export default Products;
