import React, { useEffect, useState } from "react";
import Address from "../components/Address";
import { useDispatch, useSelector } from "react-redux";
import { MdDeleteForever } from "react-icons/md";
import {
  buyNow,
  getShippingAddressAsync,
  newOrderAsync,
  order,
} from "../slice/checkout/checkoutSlice";
import { useNavigate } from "react-router";

const Checkout = ({ isChecked, setIsChecked }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const cartItems = useSelector((state) => {
    return state.cart.cartItems;
  });

  const orderItem = useSelector(order);

  console.log(orderItem);
  // const [isChecked, setIsChecked] = useState();
  console.log(isChecked);

  const itemIds = orderItem?.map((item) => item.product._id);
  const totalAmount = orderItem?.reduce(
    (amount, item) => item.product.price * item.quantity + amount,
    0
  );

  const orderDetails = {
    shippingDetails: isChecked,
    orderItems: itemIds,

    paymentInfo: {
      id: "sdkjb",
      status: "completed",
    },
    itemsPrice: totalAmount,
    taxPrice: 0,
    shippingPrice: 0,
    totalPrice: totalAmount,
  };

  const decreaseQuantity = (item) => {
    if (item.quantity > 1) {
      dispatch(
        buyNow([
          {
            product: item.product,
            quantity: item.quantity - 1,
          },
        ])
      );
    }
  };

  const increaseQuantity = (item) => {
    console.log(item);
    if (item.quantity > 0) {
      dispatch(
        buyNow([
          {
            product: item.product,
            quantity: item.quantity + 1,
          },
        ])
      );
    }
  };
  return (
    <div className="flex justify-between max-lg:block m-4 p-2">
      <div className="w-[68%] mt-8 max-lg:w-full">
        <Address isChecked={isChecked} setIsChecked={setIsChecked} />
        <div className="border mt-5 p-7">
          {orderItem &&
            orderItem.map((item) => {
              return (
                <div className="flex justify-between items-center max-sm:block">
                  <div className="flex max-sm:justify-between">
                    <div className="flex items-center">
                      <div>
                        <img
                          className="h-[100px]"
                          src={item.product.image[0].public_url}
                          alt=""
                        />
                      </div>

                      <div>
                        <p>{item.product.brand}</p>
                        <h2>{item.product.title}</h2>
                      </div>
                    </div>
                    <div className="self-center">
                      <p className="hidden max-sm:block">
                        {item.product.price}
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-evenly gap-2 w-[30%] max-sm:mt-3">
                    <div className="max-sm:hidden">{item.product.price}</div>
                    <div className="flex max-sm:justify-start"></div>

                    <div>
                      <button
                        className="border text-white w-6 bg-slate-500 text-center rounded-md"
                        onClick={() => decreaseQuantity(item)}
                      >
                        -
                      </button>
                    </div>
                    <div>{item.quantity}</div>
                    <div>
                      <button
                        className="border text-white w-6 bg-slate-500 text-center rounded-md"
                        onClick={() => increaseQuantity(item)}
                      >
                        +
                      </button>
                    </div>
                    <div
                      className="hover:cursor-pointer text-2xl"
                      onClick={() => handleRemoveItem(item._id)}
                    >
                      <MdDeleteForever />
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </div>
      <div className="border w-[29%] max-h-[250px] rounded-2xl p-6 mt-7 max-lg:w-full">
        <div>
          <h2 className="mb-3">Price Details</h2>
          <div className="flex justify-between">
            <p>Price({orderItem.length} item)</p>
            <p>${totalAmount}</p>
          </div>
          <div className="flex justify-between">
            <p>Discounts</p>
            <p>$0</p>
          </div>
          <div className="flex justify-between">
            <p>Coupons</p>
            <p>$0</p>
          </div>
          <div className="flex justify-between">
            <p>Delivery Charges</p>
            <p>Free</p>
          </div>
        </div>
        <div className="flex justify-between mt-5">
          <p>Total Amount</p>
          <p>{totalAmount}</p>
        </div>
        <div
          onClick={() => {
            navigate("/stripe-checkout", { state: orderDetails });
          }}
        >
          Place Order
        </div>
      </div>
    </div>
  );
};

export default Checkout;
