import { configureStore } from "@reduxjs/toolkit";
import authSlice from "./slice/auth/authSlice";
import productSlice from "./slice/product/productSlice";
import cartSlice from "./slice/cart/cartSlice";
import checkoutSlice from "./slice/checkout/checkoutSlice";
import wishlistSlice, { wishlist } from "./slice/wishlist/wishlistSlice";

export const store = configureStore({
  reducer: {
    auth: authSlice,
    product: productSlice,
    cart: cartSlice,
    wishlist: wishlistSlice,
    checkout: checkoutSlice,
  },
});
