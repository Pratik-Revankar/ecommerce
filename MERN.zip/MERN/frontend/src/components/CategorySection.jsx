import React, { useState } from "react";
import Dress from "../assets/icons/dress.svg";

const categories = [
  {
    category: "Cloths",
    subCategory: ["Shirt", "Jeans", "Frocks", "Kurtas"],
  },
  {
    category: "Cloths",
    subCategory: ["Shirt", "Jeans", "Frocks", "Kurtas"],
  },
  {
    category: "Cloths",
    subCategory: ["Shirt", "Jeans", "Frocks", "Kurtas"],
  },
  {
    category: "Cloths",
    subCategory: ["Shirt", "Jeans", "Frocks", "Kurtas"],
  },
  {
    category: "Cloths",
    subCategory: ["Shirt", "Jeans", "Frocks", "Kurtas"],
  },
];

const CategorySection = () => {
  const [isHidden, setIsHidden] = useState(true);
  const [activeIndex, setActiveIndex] = useState();
  return (
    <div className="w-full">
      <div>
        <div className="p-5 border rounded-lg">
          <h2 className="text-sm font-semibold mb-2">CATEGORY</h2>

          {categories.map((category, i) => (
            <div className="py-2" key={i}>
              <div
                className="flex justify-between hover:cursor-pointer"
                onClick={() => {
                  setIsHidden(!isHidden), setActiveIndex(i);
                }}
              >
                <div className="flex gap-2">
                  <img className="w-5" src={Dress} alt="" />
                  <p className="self-center">{category.category}</p>
                </div>
                <button
                  onClick={() => {
                    setIsHidden(!isHidden), setActiveIndex(i);
                  }}
                >
                  {isHidden && activeIndex === i ? "-" : "+"}
                </button>
              </div>
              {category.subCategory.map((subC) => {
                return (
                  <div
                    key={subC}
                    className={`${
                      activeIndex === i && isHidden
                        ? "transition delay-[0.5s] ease-in-out"
                        : "hidden "
                    } `}
                  >
                    <div>{subC}</div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategorySection;
