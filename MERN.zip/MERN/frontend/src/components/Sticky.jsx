import React from "react";

const Sticky = () => {
  return (
    <div className="w-[80%] m-auto flex gap-3 relative">
      <section className="w-[30%] bg-slate-400 sticky h-96">sidebar</section>
      <section className="w-[60%] bg-slate-700 h-96">main</section>
    </div>
  );
};

export default Sticky;
