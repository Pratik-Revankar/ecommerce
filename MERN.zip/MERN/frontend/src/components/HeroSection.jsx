import React, { useState } from "react";
import BannerImg1 from "../assets/images/banner-1.jpg";
import BannerImg2 from "../assets/images/banner-2.jpg";
import BannerImg3 from "../assets/images/banner-3.jpg";
import Button from "./Button";

const HeroSection = () => {
  const heroData = [
    {
      bannerTitle: "WOMEN'S LATEST FASHION SALE",
      bannerSubtitle: " Trending item",
      bannerPrice: 20.0,
      bannerImg: BannerImg1,
    },
    {
      bannerTitle: " MODERN SUNGLASSES",
      bannerSubtitle: "Trending Accessories",
      bannerPrice: 15.0,
      bannerImg: BannerImg2,
    },
    {
      bannerTitle: "NEW FASHION SUMMER SALE",
      bannerSubtitle: "Sale Offer",
      bannerPrice: 29.99,
      bannerImg: BannerImg3,
    },
  ];
  const [slide, setSlide] = useState(0);

  return (
    <>
      <div className="relative">
        <div className="mt-4 flex w-full max-h-96 px-4 m-auto max-lg:max-w-[90%] max-md:w-full ">
          {heroData.map((hero, i) => {
            return (
              <>
                <div
                  key={hero.bannerTitle}
                  className={`w-[40%] top-[20%] left-[15%] px-6 py-5 max-md:p-3 max-sm:p-2 max-xs:p-1  ${
                    slide === i ? "absolute" : "hidden"
                  } `}
                >
                  <p className="text-2xl capitalize tracking-widest text-[#ff8f9c] font-medium mb-2 max-lg:text-[20px] max-lg:mb-1 max-md:text-[16px]  max-sm:text-[12px] max-xs:text-[8px] max-md:leading-6 max-sm:leading-3 max-xs:leading-3">
                    {hero.bannerSubtitle}
                  </p>
                  <h2 className="text-3xl uppercase font-black mb-2 max-lg:text-[25px] max-lg:mb-1 max-md:text-[19px] max-md:leading-6 max-sm:text-[14px] max-sm:leading-5 max-xs:text-[11px] max-xs:leading-3">
                    {hero.bannerTitle}
                  </h2>
                  <p className="text-xl mb-2 max-lg:text-[17px] max-lg:mb-0 max-md:text-[14px] max-sm:text-[11px] max-xs:text-[9px]  max-md:leading-3 max-sm:leading-3 max-xs:leading-3">
                    starting at $
                    <b className="text-2xl font-bolder max-lg:text-[20px] max-lg:mb-0 max-md:text-[16px] max-sm:text-[12px] max-xs:text-[8px]  max-md:leading-3 max-sm:leading-3 max-xs:leading-3">
                      {hero.bannerPrice}
                    </b>
                  </p>

                  {/* <Button value="Shop now" /> */}
                </div>
                <img
                  src={hero.bannerImg}
                  alt=""
                  key={i}
                  className={`rounded-md  ${
                    slide === i ? "object-cover object-right" : "hidden"
                  }`}
                />
              </>
            );
          })}
        </div>

        <div className="absolute bottom-[1%] right-[46%]">
          {heroData.map((_, i) => (
            <button
              key={i}
              onClick={() => setSlide(i)}
              className={`w-3 h-3 border rounded-md mx-1 max-sm:w-[9px] max-sm:h-[9px] max-xs:w-[7px] max-xs:h-[7px] ${
                slide === i ? "bg-slate-600" : "bg-white "
              }`}
            ></button>
          ))}
        </div>
      </div>
    </>
  );
};

export default HeroSection;
