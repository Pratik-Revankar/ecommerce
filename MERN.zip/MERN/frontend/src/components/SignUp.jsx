import React from "react";
import Button from "./Button";
import { createUserAsync } from "../slice/auth/authSlice";
import { useDispatch } from "react-redux";

const SignUp = ({
  firstName,
  email,
  password,
  setName,
  setEmail,
  setPassword,
  toggle,
  setToggle,
}) => {
  const dispatch = useDispatch();

  return (
    <div className="font-poppins max-w-5xl mt-12 m-auto">
      <div className="w-[50%] m-auto min-h-[70%] border p-5 rounded-lg max-sm:w-[80%] max-md:w-[70%] max-lg:w-[60%]">
        <div className="m-auto w-[100%]">
          <h1 className="mb-9">Sign Up</h1>
          <div className="w-[100%]">
            <div className="relative">
              <label htmlFor="firstName" className="absolute -top-[22px]">
                Name
              </label>
              <input
                type="text"
                id="firstName"
                className="border rounded-md w-full h-[40px] px-3 mb-8"
                onChange={(e) => setName(e.target.value)}
                value={firstName}
              />
            </div>
            <div className="relative">
              <label htmlFor="email" className="absolute -top-[22px]">
                Email
              </label>
              <input
                type="email"
                id="email"
                className="border rounded-md w-full h-[40px] px-3 mb-8"
                onChange={(e) => setEmail(e.target.value)}
                value={email}
              />
            </div>
            <div className="relative">
              <label htmlFor="password" className="absolute -top-[22px] ">
                Password
              </label>
              <input
                type="password"
                id="password"
                className="border rounded-md w-full h-[40px] px-3 mb-4"
                onChange={(e) => setPassword(e.target.value)}
                value={password}
              />
            </div>
            <div
              onClick={() =>
                dispatch(
                  createUserAsync({
                    firstName,
                    email,
                    password,
                  })
                )
              }
            >
              <Button value="Sign Up" />
            </div>
            <div className="mt-4 text-center">
              Already have an account?
              <a
                href=""
                className="ml-1 text-blue-700"
                onClick={(e) => {
                  setToggle(!toggle), e.preventDefault();
                }}
              >
                Sign In
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
