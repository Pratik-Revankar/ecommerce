import React, { useEffect, useState } from "react";

import Slider from "@mui/material/Slider";
import { IoIosArrowDown } from "react-icons/io";
import { IoIosArrowUp } from "react-icons/io";
import { getProductsAsync, product } from "../slice/product/productSlice";
import { useDispatch, useSelector } from "react-redux";

const Price = ({ category, selectedBrand }) => {
  const dispatch = useDispatch();
  const products = useSelector(product);
  // console.log(products);
  // Our States
  const keyword = "";
  const [value, setValue] = useState([0, 10000]);
  const [toggle, setToggle] = useState(false);

  // Changing State when volume increases/decreases
  const rangeSelector = (event, newValue) => {
    setValue(newValue);
  };

  const handlePriceFilter = () => {
    dispatch(
      getProductsAsync({
        category,
        brand: selectedBrand,
        keyword,
        price: value,
      })
    );
  };

  return (
    <div className="block p-2 w-full ">
      <div className="flex justify-between items-center">
        <div>Price</div>
        <div onClick={() => setToggle(!toggle)}>
          {toggle ? <IoIosArrowUp /> : <IoIosArrowDown />}
        </div>
      </div>
      {toggle && (
        <div className="w-full flex gap-2 justify-between items-center mt-2">
          <div className="w-[70%]">
            <Slider
              value={value}
              onChange={rangeSelector}
              max={25000}
              size={"small"}
              step={250}
              valueLabelDisplay="auto"
            />
          </div>

          <button
            onClick={handlePriceFilter}
            className="border-2 mb-1 p-1 rounded-2xl"
          >
            Go
          </button>
        </div>
      )}
    </div>
  );
};

export default Price;
