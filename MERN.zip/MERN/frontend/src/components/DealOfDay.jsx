import React from "react";
import Shampoo from "../assets/images/shampoo.jpg";
import Button from "./Button";
const arr = [1, 2];
const DealOfDay = () => {
  return (
    <div className="flex border overflow-x-scroll">
      {arr.map(() => {
        return (
          <div className="min-w-[704px] mr-0 border rounded-md p-7 m-auto">
            <div className="flex gap-3">
              <div className="w-1/2">
                <img src={Shampoo} alt="" />
              </div>
              <div className="self-center w-1/2">
                <h3 className="text-xs font-bold mb-2">
                  SHAMPOO, CONDITIONER & FACEWASH PACKS
                </h3>
                <p className="text-xs font-light mb-2">
                  Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor
                  sit amet consectetur Lorem ipsum dolor
                </p>
                <p>⭐⭐⭐</p>
                <div className="flex gap-2 mb-3">
                  <p className="text-[#ff8f9c] font-extrabold">$150.00</p>
                  <del>$200.00</del>
                </div>
                <div className="mb-2">
                  <Button value="Add to Cart" />
                </div>
                <p className="text-xs mb-3">HURRY UP! OFFER ENDS IN:</p>
                <div className="flex gap-2 text-center">
                  <div className="border rounded-lg w-14 h-14 p-1">
                    <p className=" text-lg font-semibold">3</p>
                    <p className="text-[11px]">Days</p>
                  </div>
                  <div className="border rounded-lg w-14 h-14 p-1">
                    <p className=" text-lg font-semibold">10</p>
                    <p className="text-[11px]">Hours</p>
                  </div>
                  <div className="border rounded-lg w-14 h-14 p-1">
                    <p className=" text-lg font-semibold">5</p>
                    <p className="text-[11px]">Min</p>
                  </div>
                  <div className="border rounded-lg w-14 h-14 p-1">
                    <p className="text-lg font-semibold">30</p>
                    <p className="text-[11px]">Sec</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DealOfDay;
