import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  address,
  addShippingAddressAsync,
  editShippingAddressAsync,
  getShippingAddressAsync,
} from "../slice/checkout/checkoutSlice";

const Address = ({ isChecked, setIsChecked }) => {
  const shippingDetails = useSelector(address);
  const dispatch = useDispatch();
  const [toggle, setToggle] = useState(false);
  //   const [isChecked, setIsChecked] = useState(shippingDetails[0]?._id || null);
  const [isEdit, setIsEdit] = useState(false);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    dispatch(getShippingAddressAsync());

    if (!toggle) {
      setIsChecked(shippingDetails[0]?._id);
    } else setIsChecked(shippingDetails[shippingDetails.length - 1]?._id);
  }, [shippingDetails]);

  const [addressForm, setAddressForm] = useState({
    name: "",
    phoneNo: "",
    pinCode: "",
    city: "",
    state: "",
    address: "",
  });
  const [editAddress, setEditAddress] = useState({
    name: "",
    phoneNo: "",
    pinCode: "",
    city: "",
    state: "",
    address: "",
  });
  const handleEditChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setEditAddress((prev) => {
      if (name == "phoneNo" || name == "pinCode") {
        return { ...prev, [name]: +value };
      }

      return { ...prev, [name]: value };
    });
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    setAddressForm((prev) => {
      if (name == "phoneNo" || name == "pinCode") {
        return { ...prev, [name]: +value };
      }

      return { ...prev, [name]: value };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setAddressForm({
      name: "",
      phoneNo: "",
      pinCode: "",
      city: "",
      state: "",
      address: "",
    });

    dispatch(addShippingAddressAsync(addressForm)).then(() =>
      dispatch(getShippingAddressAsync())
    );
  };

  const handleIsChecked = (e) => {
    setIsChecked(e.target.value);
  };

  const handleEdit = () => {
    setIsEdit(!isEdit);

    shippingDetails.map((address) => {
      if (address._id == isChecked) {
        setEditAddress({
          name: address.shippingInfo.name,
          phoneNo: address.shippingInfo.phoneNo,
          pinCode: address.shippingInfo.pinCode,
          city: address.shippingInfo.city,
          state: address.shippingInfo.state,
          address: address.shippingInfo.address,
        });
      }
    });
  };
  const initialItemCount = 3;
  const visibleItems = showAll
    ? shippingDetails
    : shippingDetails.slice(0, initialItemCount);
  const toggleShowAll = () => {
    setShowAll(!showAll);
  };
  return (
    <div className="border px-10 py-7">
      <div>
        {visibleItems.map((address) => {
          return (
            <div className="flex mb-3">
              <div className="w-[5%] mr-2">
                <input
                  type="radio"
                  name=""
                  id=""
                  value={address._id}
                  checked={isChecked === address._id.toString()}
                  onChange={handleIsChecked}
                />
              </div>
              <div className="flex justify-between gap-3 w-[100%]">
                <div className="w-[80%]">
                  {isEdit && isChecked === address._id ? (
                    <form
                      className="w-full"
                      action=""
                      onSubmit={(e) => {
                        e.preventDefault(),
                          dispatch(
                            editShippingAddressAsync({
                              id: isChecked,
                              details: editAddress,
                            })
                          ).then(() => {
                            dispatch(getShippingAddressAsync());
                          });
                        setIsEdit(!isEdit);
                      }}
                    >
                      <div className="flex flex-col gap-5 ">
                        <div className="flex gap-2 w-full max-xs:flex-wrap">
                          <div className="relative w-[50%] max-xs:w-full ">
                            <label
                              htmlFor="name"
                              className="absolute left-1 text-xs"
                            >
                              Name
                            </label>
                            <input
                              id="name"
                              name="name"
                              type="text"
                              value={editAddress.name}
                              className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                              onChange={handleEditChange}
                            />
                          </div>
                          <div className="relative w-[50%]  max-xs:w-full ">
                            <label
                              htmlFor=""
                              className="absolute left-1 text-xs"
                            >
                              Mobile
                            </label>
                            <input
                              type="number"
                              name="phoneNo"
                              value={editAddress.phoneNo}
                              className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                              onChange={handleEditChange}
                            />
                          </div>
                        </div>
                        <div className="flex gap-2 w-full max-xs:flex-wrap">
                          <div className="relative w-[50%] max-xs:w-full">
                            <label
                              htmlFor=""
                              className="absolute left-1 text-xs"
                            >
                              Pincode
                            </label>
                            <input
                              type="number"
                              name="pinCode"
                              value={editAddress.pinCode}
                              className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                              onChange={handleEditChange}
                            />
                          </div>
                          <div className="relative w-[50%] max-xs:w-full">
                            <label
                              htmlFor=""
                              className="absolute left-1 text-xs"
                            >
                              City
                            </label>
                            <input
                              type="text"
                              name="city"
                              value={editAddress.city}
                              className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                              onChange={handleEditChange}
                            />
                          </div>
                        </div>
                        <div className="flex gap-2 w-full max-xs:flex-wrap">
                          <div className="relative w-[50%] max-xs:w-full">
                            <label
                              htmlFor=""
                              className="absolute left-1 text-xs"
                            >
                              State
                            </label>
                            <input
                              type="text"
                              name="state"
                              value={editAddress.state}
                              className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                              onChange={handleEditChange}
                            />
                          </div>
                          <div className="relative w-[50%] max-xs:w-full">
                            <label
                              htmlFor=""
                              className="absolute left-1 text-xs"
                            >
                              Country
                            </label>
                            <input
                              type="text"
                              defaultValue="India"
                              disabled
                              className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                            />
                          </div>
                        </div>
                        <div className="flex gap-2 w-full">
                          <div className="relative w-full">
                            <label
                              htmlFor="address"
                              className="absolute left-1 text-xs"
                            >
                              Address
                            </label>
                            <textarea
                              name="address"
                              id="address"
                              value={editAddress.address}
                              className="w-full h-[90px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 resize-none"
                              onChange={handleEditChange}
                            ></textarea>
                          </div>
                        </div>
                        <div className="flex gap-3">
                          <button>Save</button>
                          <div onClick={() => setIsEdit(!isEdit)}>Cancel</div>
                          {/* <button onClick={() => setToggle(!isEdit)}>Cancel</button> */}
                        </div>
                      </div>
                    </form>
                  ) : (
                    <div className="w-[70%]">
                      <div className="mb-1">
                        <p>
                          <span>{address.shippingInfo.name}</span>{" "}
                          <span>{address.shippingInfo.phoneNo}</span>
                        </p>
                      </div>
                      <div>
                        <span>
                          {address.shippingInfo.address +
                            " " +
                            address.shippingInfo.city +
                            " " +
                            address.shippingInfo.state +
                            "-" +
                            address.shippingInfo.pinCode}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
                <div className="w-[8%] ml-2">
                  {isChecked === address._id && (
                    <div onClick={handleEdit}>Edit</div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <div>
        {!showAll && shippingDetails.length > initialItemCount && (
          <button onClick={toggleShowAll}>View All Items</button>
        )}
      </div>
      <div
        onClick={() => {
          setToggle(!toggle);
        }}
      >
        Add new address
      </div>
      {toggle && (
        <form className="w-[90%] mt-4" action="" onSubmit={handleSubmit}>
          <div className="flex flex-col gap-2">
            <div className="flex gap-2 w-full max-xs:flex-wrap">
              <div className="relative w-[50%] max-xs:w-full">
                <label htmlFor="name" className="absolute left-1 text-xs">
                  Name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={addressForm.name}
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                  onChange={handleChange}
                />
              </div>
              <div className="relative w-[50%] max-xs:w-full">
                <label htmlFor="" className="absolute left-1 text-xs">
                  Mobile
                </label>
                <input
                  type="number"
                  name="phoneNo"
                  value={addressForm.phoneNo}
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="flex gap-2 w-full max-xs:flex-wrap">
              <div className="relative w-[50%] max-xs:w-full">
                <label htmlFor="" className="absolute left-1 text-xs">
                  Pincode
                </label>
                <input
                  type="number"
                  name="pinCode"
                  value={addressForm.pinCode}
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                  onChange={handleChange}
                />
              </div>
              <div className="relative w-[50%] max-xs:w-full">
                <label htmlFor="" className="absolute left-1 text-xs">
                  City
                </label>
                <input
                  type="text"
                  name="city"
                  value={addressForm.city}
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="flex gap-2 w-full max-xs:flex-wrap">
              <div className="relative w-[50%] max-xs:w-full">
                <label htmlFor="" className="absolute left-1 text-xs">
                  State
                </label>
                <input
                  type="text"
                  name="state"
                  value={addressForm.state}
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                  onChange={handleChange}
                />
              </div>
              <div className="relative w-[50%] max-xs:w-full">
                <label htmlFor="" className="absolute left-1 text-xs">
                  Country
                </label>
                <input
                  type="text"
                  defaultValue="India"
                  disabled
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                />
              </div>
            </div>
            <div className="flex gap-2 w-full max-xs:flex-wrap">
              <div className="relative w-full max-xs:w-full">
                <label htmlFor="address" className="absolute left-1 text-xs">
                  Address
                </label>
                <textarea
                  name="address"
                  id="address"
                  value={addressForm.address}
                  className="w-full h-[90px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 resize-none"
                  onChange={handleChange}
                ></textarea>
              </div>
            </div>
            <div>
              <button className="mr-4">Submit</button>
              <button onClick={() => setToggle(!toggle)}>Cancel</button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};

export default Address;
