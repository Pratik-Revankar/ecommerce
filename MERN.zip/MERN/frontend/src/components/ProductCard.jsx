import React, { useEffect } from "react";
import Jacket from "../assets/images/jacket-1.jpg";
import CategorySection from "./CategorySection";
import DealOfDay from "./DealOfDay";
import BestSeller from "./BestSeller";
import CategoryCard from "./CategoryCard";
import NewArrivals from "./NewArrivals";
import { useDispatch, useSelector } from "react-redux";
import {
  getProductDetailsAsync,
  getProductsAsync,
  product,
} from "../slice/product/productSlice";
import { current } from "@reduxjs/toolkit";
import { Navigate, useNavigate } from "react-router";
const ProductCard = () => {
  // const products = [
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  //   {
  //     img: Jacket,
  //     title: " Mens Winter Leathers Jackets",
  //     category: "Jacket",
  //     price: 75.0,
  //     offerPrice: 48.0,
  //   },
  // ];
  // useEffect(() => {
  //   dispatch(
  //     getProductsAsync({
  //       keyword: "",
  //       currentPage: 1,
  //       price: [0, 3000],
  //       category: "",
  //     })
  //   );
  // }, []);
  // const dispatch = useDispatch();
  const products = useSelector(product);
  // console.log(products);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  return (
    <div className="px-4 mt-4">
      <div className="flex gap-7 ">
        {/* <div className=""> 
         <CategorySection /> 
        <BestSeller /> 
        </div> */}
        <div className="w-full">
          {/* <div>
            <NewArrivals />
          </div>
          <div className="mt-4">
            <DealOfDay />
          </div> */}
          <div className="max-w-[704px] grid grid-cols-3 gap-7 mt-4 m-auto">
            {products.map((product, i) => {
              return (
                <div
                  key={i}
                  className="border-[1px] flex flex-col justify-between rounded-lg hover:shadow-lg min-h-[350px]"
                  onClick={() => {
                    // console.log(product._id);
                    dispatch(getProductDetailsAsync(product._id));

                    navigate("/product/details");
                  }}
                >
                  <div className="h-[60%]">
                    <img
                      src={product.image[0].public_url}
                      alt=""
                      className="rounded-lg h-40 m-auto"
                    />
                  </div>
                  <div className="p-4">
                    <p className="text-[#ff8f9c] text-xs uppercase font-medium mb-2 tracking-wide">
                      {product.category}
                    </p>
                    <h3 className="font-light text-sm tracking-wider text-[#787878] mb-2">
                      {product.title}
                    </h3>
                    <h3 className="font-light text-sm tracking-wider text-[#787878] mb-2">
                      {product.brand}
                    </h3>
                    <p>⭐⭐⭐</p>
                    <div className="flex gap-2">
                      <p className="font-extrabold">${product.price}</p>
                      <del className="text-[#787878]">${product.price}</del>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
