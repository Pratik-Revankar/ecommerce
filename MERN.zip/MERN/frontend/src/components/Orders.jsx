import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { myOrdersAsync, orders } from "../slice/checkout/checkoutSlice";
import { userToken } from "../slice/auth/authSlice";
import { useNavigate } from "react-router";
import { FaDove } from "react-icons/fa";

const Orders = () => {
  const dispatch = useDispatch();
  const myOrders = useSelector(orders);
  const navigate = useNavigate();
  const token = useSelector(userToken);
  console.log(myOrders);
  useEffect(() => {
    if (!token) {
      navigate("/login");
    }
    dispatch(myOrdersAsync());
  }, []);
  return (
    <>
      <div>
        {myOrders?.map((order) => {
          return (
            <>
              <div className="flex mb-3  justify-between border rounded-lg p-5 max-lg:flex-col">
                <div className="w-[45%] max-lg:mb-3">
                  {order.orderItems.map((item) => {
                    return (
                      <div className="flex items-center">
                        <div className="mx-2">
                          <img
                            className="h-[75px]"
                            src={item.image[0].public_url}
                            alt=""
                          />
                        </div>

                        <div className="w-[80%]">
                          <p>{item.brand}</p>
                          <h2>{item.title}</h2>
                        </div>
                        {/* <div>
                      <h2>{item.price}</h2>
                    </div> */}
                      </div>
                    );
                  })}
                </div>

                <div className="max-lg:ml-5 max-lg:mb-1">
                  Total Price: {order.totalPrice}
                </div>
                <div className="max-lg:ml-5 max-lg:mb-1">
                  Status: {order.orderStatus}
                </div>
              </div>
            </>
          );
        })}
      </div>
    </>
  );
};

export default Orders;
