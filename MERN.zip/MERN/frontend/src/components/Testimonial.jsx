import React from "react";
import { IoBoatOutline } from "react-icons/io5";
import { IoRocketOutline } from "react-icons/io5";
import { IoCallOutline } from "react-icons/io5";
import { IoArrowUndoOutline } from "react-icons/io5";
import { IoTicketOutline } from "react-icons/io5";
import CTABanner from "../assets/images/cta-banner.jpg";
import Profile from "../assets/images/testimonial-1.jpg";
import { FaQuoteLeft } from "react-icons/fa";
const Testimonial = () => {
  return (
    <div className="w-full">
      <div className="flex w-[95%] gap-7 mb-9 mt-7 m-auto max-xl:flex-wrap">
        <div className=" m-auto max-md:w-[85%] max-lg:w-[70%]">
          <h3 className="pb-2">Testimonial</h3>
          <div className="border rounded-lg mt-6">
            <div className="text-center p-6 max-sm:p-3 max-xs:p-2 ">
              <div className="w-[60px] mb-3 m-auto ">
                <img
                  className="object-contain rounded-full"
                  src={Profile}
                  alt=""
                />
              </div>

              <h3 className="font-semibold mb-1">ALAN DOE</h3>
              <p className="text-sm mb-2">CEO & Founder Invision</p>
              <FaQuoteLeft className="m-auto text-xl mb-1" />
              <p className="max-w-[70%] m-auto text-sm">
                Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor
                sit amet.
              </p>
            </div>
          </div>
        </div>

        <div className="min-w-[43%] m-auto max-md:w-[85%] max-lg:w-[70%]">
          <div className="relative ">
            <img src={CTABanner} alt="" className="rounded-lg w-full" />
            <div className="absolute bg-white/70 w-[50%] p-6 top-[20%] left-[25%] rounded-md max-md:p-4 max-sm:p-3">
              <div className="text-center">
                <p className="text-white  bg-black p-1 rounded-md font-bold text-sm uppercase max-md:text-[12px] max-sm:text-[10px]">
                  25% Discount
                </p>
                <h2 className="text-2xl mt-1 font-bold max-sm:text-[16.5px] max-md:text-[18.5px] max-lg:text-[20px] max-sm:leading-4">
                  Summer Collection
                </h2>
                <p className="max-sm:text-[13px]">Starting @ $10</p>
                <button className="uppercase font-bold text-sm max-sm:text-[13px] ">
                  Shop Now
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="min-w-[24%] max-xl:w-[85%] m-auto">
          <h3 className="pb-2">Our Services</h3>

          <div className="flex flex-col  gap-4 p-6 border rounded-lg mt-6 max-xl:flex-row flex-wrap justify-center ">
            <div className="flex gap-4">
              <div className="text-3xl self-center">
                <IoBoatOutline />
              </div>

              <div>
                <h3 className="text-sm font-semibold">Worldwide Delivery</h3>
                <p className="text-xs">For Order Over $100</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="text-3xl self-center">
                <IoRocketOutline />
              </div>

              <div>
                <h3 className="text-sm font-semibold">Next Day Delivery</h3>
                <p className="text-xs">UK Orders Only</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="text-3xl self-center">
                <IoCallOutline />
              </div>

              <div>
                <h3 className="text-sm font-semibold">Best Online Support</h3>
                <p className="text-xs">Hours: 8AM - 11PM</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="text-3xl self-center">
                <IoArrowUndoOutline />
              </div>

              <div>
                <h3 className="text-sm font-semibold">Return Policy</h3>
                <p className="text-xs">Easy & Free Return</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="text-3xl self-center">
                <IoTicketOutline />
              </div>

              <div>
                <h3 className="text-sm font-semibold">30% Money Back</h3>
                <p className="text-xs">For Order Over $100</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Testimonial;
