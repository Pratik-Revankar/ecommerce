import React, { useEffect, useState } from "react";
import Categories from "./Categories";
import HeroSection from "./HeroSection";

import Testimonial from "./Testimonial";
import Blog from "./Blog";

const Home = () => {
  // const dispatch = useDispatch();

  const categories = [
    "Home",
    "smartphone",
    "Men's",
    "Women's",
    "Jewelry",
    "Perfume",
    "Blog",
    "Hot Offers",
  ];

  return (
    <div className="max-w-5xl m-auto">
      <Categories categories={categories} />

      <HeroSection />
      {/* <CategoryCard /> */}
      {/* <ProductCard /> */}
      {/* <DealOfDay /> */}
      {/* <Card /> */}
      <Testimonial />
      <Blog />
      {/* <Sticky /> */}
      {/* <div className="w-[80%] h-96 bg-slate-900"></div> */}
    </div>
  );
};

export default Home;
