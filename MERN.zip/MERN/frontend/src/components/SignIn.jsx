import React, { useEffect } from "react";
import { loginAsync } from "../slice/auth/authSlice";
import { useDispatch } from "react-redux";
import Button from "./Button";
import { getUserCartDetailsAsync } from "../slice/cart/cartSlice";

const SignIn = ({
  email,
  password,
  setEmail,
  setPassword,
  toggle,
  setToggle,
}) => {
  const dispatch = useDispatch();

  return (
    <div className="font-poppins max-w-5xl mt-12 m-auto">
      <div className="w-[50%] m-auto min-h-[70%] border p-5 rounded-lg max-sm:w-[80%] max-md:w-[70%] max-lg:w-[60%]">
        <div className="m-auto w-[100%]">
          <h1 className="mb-9">Sign In</h1>
          <div className="relative">
            <label htmlFor="email" className="absolute -top-[22px] ">
              Email
            </label>
            <input
              type="email"
              id="email"
              className="border rounded-md w-full h-[40px] px-3 mb-8"
              onChange={(e) => setEmail(e.target.value)}
              value={email}
            />
          </div>
          <div className="relative">
            <label htmlFor="password" className="absolute -top-[22px]">
              Password
            </label>
            <input
              type="password"
              id="password"
              className="border rounded-md w-full h-[40px] px-3 mb-4"
              onChange={(e) => setPassword(e.target.value)}
              value={password}
            />
          </div>
          <div
            onClick={() =>
              dispatch(
                loginAsync({
                  email,
                  password,
                })
              ).then(() => {
                dispatch(getUserCartDetailsAsync());
              })
            }
          >
            <Button value="Sign In" />
          </div>
          <div className="mt-4 text-center">
            Don't have an account?
            <a
              href=""
              className="ml-1 text-blue-700"
              onClick={(e) => {
                setToggle(!toggle), e.preventDefault();
              }}
            >
              Sign Up
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
