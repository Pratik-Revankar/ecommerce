import React from "react";
import BlogImg from "../assets/images/blog-1.jpg";
const Blog = () => {
  const arr = [1, 2, 3, 4];
  return (
    <div className="flex w-[95%] mb-14 m-auto gap-7 overflow-x-scroll no-scrollbar">
      {arr.map(() => {
        return (
          <div className="min-w-[200px]">
            <div>
              <img className="rounded-lg" src={BlogImg} alt="" />
            </div>
            <div>
              <p>Fashion</p>
              <h3>Clothes Retail KPIs 2021 Guide for Clothes Executives.</h3>
              <p>By Mr Admin / Apr 06, 2022</p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Blog;
