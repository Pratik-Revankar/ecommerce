import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { logoutAsync, userToken } from "../slice/auth/authSlice";
import { Link } from "react-router-dom";
import { IoClose } from "react-icons/io5";

const SideNav = ({ toggle, setToggle, categories }) => {
  const dispatch = useDispatch();

  const token = useSelector(userToken);
  return (
    <div>
      {toggle && (
        <div>
          {toggle === "category" ? (
            <div className="hidden z-10 bg-slate-300 h-[calc(100vh-44px)] fixed top-0 w-[55vw]  max-sm:block">
              <div className="flex relative">
                <div className="p-5 flex flex-col gap-3">
                  {categories.map((category, i) => {
                    return <div>{category?.toUpperCase()}</div>;
                  })}
                </div>
                <div className="p-3 text-2xl absolute right-0">
                  <IoClose
                    className="hover:cursor-pointer"
                    onClick={() => setToggle("")}
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="hidden z-10 bg-slate-300 h-[calc(100vh-44px)] fixed top-0 w-[55vw]  max-sm:block">
              <div className="flex relative">
                <div className="p-5 flex flex-col gap-3">
                  {token ? (
                    <Link to="/">
                      <div
                        onClick={() => {
                          dispatch(logoutAsync()), setToggle("");
                        }}
                        className="hover:cursor-pointer"
                      >
                        Logout
                      </div>
                    </Link>
                  ) : (
                    <Link to="/login">
                      <div onClick={() => setToggle("")}>Login</div>
                    </Link>
                  )}
                  <hr />
                  <Link to="/myprofile">
                    <div onClick={() => setToggle("")}>My Profile</div>
                  </Link>
                  <hr />
                  <Link to="/orders">
                    <div onClick={() => setToggle("")}>Orders</div>
                  </Link>
                </div>
                <div className="p-3 text-2xl absolute right-0">
                  <IoClose
                    className="hover:cursor-pointer"
                    onClick={() => setToggle("")}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SideNav;
