import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { IoClose } from "react-icons/io5";
import {
  getProductsAsync,
  getProductsByBrandAsync,
  getProductsByCategoryAsync,
  product,
} from "../slice/product/productSlice";
import { useNavigate } from "react-router";
import { logoutAsync, userToken } from "../slice/auth/authSlice";
import { Link } from "react-router-dom";

const Categories = ({ toggle, setToggle, categories }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // const products = useSelector(product);
  const token = useSelector(userToken);
  const brand = "puma";
  const keyword = "";
  return (
    <>
      <div>
        <div className="flex max-sm:hidden mt-10 justify-evenly font-poppins px-4 max-md:text-[15px] max-sm:text-[10px] max-xs:text-[6.6px]">
          {categories.map((category, i) => {
            return (
              <div
                className="hover:cursor-pointer"
                key={i}
                onClick={() => {
                  // dispatch(getProductsByBrandAsync({ category, brand })),

                  dispatch(getProductsAsync({ category, brand, keyword }));
                  navigate(`products/${category}`);
                }}
              >
                {category?.toUpperCase()}
              </div>
            );
          })}
        </div>
        {toggle && (
          <div>
            {toggle === "category" ? (
              <div className="hidden z-10 bg-slate-300 h-[calc(100vh-44px)] fixed top-0 w-[55vw]  max-sm:block">
                <div className="flex relative">
                  <div className="p-5 flex flex-col gap-3">
                    {categories.map((category, i) => {
                      return <div>{category?.toUpperCase()}</div>;
                    })}
                  </div>
                  <div className="p-3 text-2xl absolute right-0">
                    <IoClose
                      className="hover:cursor-pointer"
                      onClick={() => setToggle("")}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="hidden z-10 bg-slate-300 h-[calc(100vh-44px)] fixed top-0 w-[55vw]  max-sm:block">
                <div className="flex relative">
                  <div className="p-5 flex flex-col gap-3">
                    {token ? (
                      <div onClick={() => dispatch(logoutAsync())}>Logout</div>
                    ) : (
                      <Link to="/login">
                        <div>Login</div>
                      </Link>
                    )}
                    <hr />
                    <Link to="/myprofile">
                      <div>My Profile</div>
                    </Link>
                    <hr />
                    <Link to="/orders">
                      <div>Orders</div>
                    </Link>
                  </div>
                  <div className="p-3 text-2xl absolute right-0">
                    <IoClose
                      className="hover:cursor-pointer"
                      onClick={() => setToggle("")}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

export default Categories;
