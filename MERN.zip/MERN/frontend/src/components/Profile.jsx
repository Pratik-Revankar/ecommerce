import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import {
  getUserDetailsAsync,
  logoutAsync,
  userToken,
} from "../slice/auth/authSlice";

const Profile = () => {
  const token = useSelector(userToken);
  const dispatch = useDispatch();
  return (
    <div className="absolute z-10 top-10 hidden w-[120px] bg-slate-300 mb-3 rounded-lg p-2 group-hover:block hover:cursor-pointer ">
      {token ? (
        <div
          className="hover:cursor-pointer"
          onClick={() => dispatch(logoutAsync())}
        >
          Logout
        </div>
      ) : (
        <Link to="/login">
          <div>Login</div>
        </Link>
      )}
      <hr />
      <Link to="/myprofile">
        <div>My Profile</div>
      </Link>
      <hr />
      <Link to="/orders">
        <div>Orders</div>
      </Link>
    </div>
  );
};

export default Profile;
