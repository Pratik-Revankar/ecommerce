import React from "react";

const Button = ({ value }) => {
  return (
    <button className="uppercase bg-[#ff8f9c] text-white py-1 rounded-md px-3 text-sm font-bold">
      {value}
    </button>
  );
};

export default Button;
