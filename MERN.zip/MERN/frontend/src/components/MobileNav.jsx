import React, { useState } from "react";
import { IoHomeOutline } from "react-icons/io5";
import { RxHamburgerMenu } from "react-icons/rx";
import { CgProfile } from "react-icons/cg";
import { LuHeart } from "react-icons/lu";
import { IoCartOutline } from "react-icons/io5";

import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
const MobileNav = ({ toggle, setToggle }) => {
  const cartItemCount = useSelector((state) => {
    if (!state.cart.loading) {
      return state.cart.cartItems?.length;
    }
  });
  return (
    <div className="hidden mt-4 max-sm:block w-[100%] h-[44px] fixed bottom-0 bg-red-100">
      <div className="flex justify-evenly text-2xl p-2">
        <RxHamburgerMenu
          className="hover:cursor-pointer"
          onClick={() => setToggle("category")}
        />
        <LuHeart className="hover:cursor-pointer" />
        <Link to="/">
          <IoHomeOutline />
        </Link>
        {/* <IoCartOutline /> */}
        <Link to="/cart">
          <div className="relative">
            <IoCartOutline />
            {cartItemCount > 0 && (
              <div className="absolute -top-2 -right-1 text-xs">
                {cartItemCount}
              </div>
            )}
          </div>
        </Link>

        <CgProfile
          className="hover:cursor-pointer"
          onClick={() => setToggle("profile")}
        />
      </div>
    </div>
  );
};

export default MobileNav;
