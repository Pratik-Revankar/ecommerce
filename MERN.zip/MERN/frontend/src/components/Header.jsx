import React, { useEffect, useState } from "react";
import { CgProfile } from "react-icons/cg";
import { LuHeart } from "react-icons/lu";
import { IoCartOutline } from "react-icons/io5";
import { GiHamburgerMenu } from "react-icons/gi";
import { IoSearch } from "react-icons/io5";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getProductsAsync } from "../slice/product/productSlice";
import { getUserCartDetailsAsync } from "../slice/cart/cartSlice";
import { getShippingAddressAsync } from "../slice/checkout/checkoutSlice";
import Profile from "./Profile";
import { user, userToken } from "../slice/auth/authSlice";
const Header = ({ search, setSearch }) => {
  const [toggle, setToggle] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const token = useSelector(userToken);
  const userData = useSelector(user);
  console.log(userData);
  const cartItemCount = useSelector((state) => {
    if (!state.cart.loading) {
      return state.cart.cartItems?.length;
    }
  });

  // useEffect(() => {
  //   dispatch(getUserCartDetailsAsync());
  // }, []);

  return (
    <>
      <div className=" max-w-5xl flex justify-center">
        <div className="flex w-full mx-3 justify-between mt-4 mb-4 max-sm:w-[80%]">
          <Link to="/">
            <li className="text-4xl list-none">Logo</li>
          </Link>
          <div className="w-[50%] relative flex max-sm:w-[63%]">
            <form
              action=""
              className="w-[100%]"
              onSubmit={(e) => {
                e.preventDefault(), navigate("/products");
                dispatch(
                  getProductsAsync({
                    keyword: search,
                    currentPage: 1,
                    price: [0, 3000],
                    category: "",
                  })
                );
              }}
            >
              <input
                type="text"
                className="w-full h-full border-2 border-black rounded-lg px-3"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </form>
            <IoSearch className="absolute top-3 right-2 text-lg" />
          </div>

          <div className="flex justify-evenly w-40 max-sm:hidden">
            <div className="group relative">
              {!token ? (
                <CgProfile
                  className="text-3xl hover:cursor-pointer"
                  onClick={() => setToggle(!toggle)}
                />
              ) : (
                <div
                  className="hover:cursor-pointer"
                  onClick={() => setToggle(!toggle)}
                >
                  {userData.firstName}
                </div>
              )}
              <Profile />
            </div>

            <Link to="/wishlist">
              <LuHeart className="text-3xl" />
            </Link>

            <Link to="/cart">
              <div className="relative">
                <IoCartOutline className="text-3xl" />
                {cartItemCount > 0 && token && (
                  <div className="absolute -top-2 -right-1 text-xs">
                    {cartItemCount}
                  </div>
                )}
              </div>
            </Link>
          </div>

          {/* <div className="hidden max-sm:block self-center text-3xl hover:cursor-pointer">
            <Link to="/cart">
              <div className="relative">
                <IoCartOutline className="text-3xl" />
                {cartItemCount > 0 && (
                  <div className="absolute -top-2 -right-1 text-xs">
                    {cartItemCount}
                  </div>
                )}
              </div>
            </Link>
          </div> */}
        </div>
      </div>
    </>
  );
};

export default Header;
