import React from "react";

import Shoes from "../assets/images/sports-1.jpg";

const arr = [1, 2, 3, 4, 5, 6, 7, 8];

const CategoryCard = () => {
  return (
    <div className="grid grid-cols-2 gap-x-60 overflow-x-scroll scrollbar-none">
      {arr.map(() => {
        return (
          // <div className="w-full">
          <div className="p-3 min-w-[220px] max-h-[80px] flex gap-5 border-2 mt-4 rounded-xl">
            <div className="w-[60px]">
              <img src={Shoes} alt="" />
            </div>
            <div>
              <h4 className="text-ellipsis text-xs font-semibold">
                Running & Trekk
              </h4>
              <p className="text-xs">Sports</p>
              <div className="flex items-center gap-1">
                <p className="text-sm text-[#ff8f9c] font-bold">$49</p>
                <del className="text-xs">$99</del>
              </div>
            </div>
          </div>
          // </div>
        );
      })}
    </div>
  );
};

export default CategoryCard;
