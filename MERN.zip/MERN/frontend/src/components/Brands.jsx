import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  brand,
  getBrandsByCategoryAsync,
  getProductsAsync,
  getProductsByBrandAsync,
} from "../slice/product/productSlice";
import { IoIosArrowDown } from "react-icons/io";
import { IoIosArrowUp } from "react-icons/io";

const Brands = ({ category, selectedBrand, setSelectedBrand }) => {
  const [toggle, setToggle] = useState(false);
  const keyword = "";
  const [displayBrand, setDisplayBrand] = useState([]);
  // const [brands, setBrands] = useState([]);
  const dispatch = useDispatch();
  const brandss = useSelector(brand);
  useEffect(() => {
    setDisplayBrand(brandss);
    dispatch(getProductsAsync({ category, brand: selectedBrand, keyword }));
  }, [selectedBrand]);

  return (
    <>
      {displayBrand.length > 0 && (
        <div className="p-2 max-sm:w-full">
          <div className="flex gap-2 justify-between items-center">
            <div>Brands</div>
            <div onClick={() => setToggle(!toggle)}>
              {toggle ? <IoIosArrowUp /> : <IoIosArrowDown />}
            </div>
          </div>
          {toggle && (
            <div>
              {displayBrand.map((brand) => (
                <div className="flex gap-2 pl-2 mt-1">
                  <input
                    type="checkbox"
                    onChange={(e) => {
                      setSelectedBrand(
                        e.target.checked
                          ? [...selectedBrand, brand]
                          : selectedBrand.filter((item) => item !== brand)
                      );
                    }}
                  />
                  <div>{brand}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default Brands;
