import React from "react";

import Shoes from "../assets/images/sports-1.jpg";
const BestSeller = () => {
  return (
    <div>
      <h3>Best Sellers</h3>
      <div>
        <div className="p-4 min-w-[260px] flex gap-5 border-2 mt-4 rounded-xl">
          <div className="w-[70px]">
            <img src={Shoes} alt="" />
          </div>
          <div>
            <h4 className="text-ellipsis text-sm">Running & Trekk</h4>
            <p>Sports</p>
            <div className="flex gap-1">
              <p>$49</p>
              <del>$99</del>
            </div>
          </div>
        </div>
        <div className="p-4 min-w-[260px] flex gap-5 border-2 mt-4 rounded-xl">
          <div className="w-[70px]">
            <img src={Shoes} alt="" />
          </div>
          <div>
            <h4 className="text-ellipsis text-sm">Running & Trekk</h4>
            <p>Sports</p>
            <div className="flex gap-1">
              <p>$49</p>
              <del>$99</del>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BestSeller;
