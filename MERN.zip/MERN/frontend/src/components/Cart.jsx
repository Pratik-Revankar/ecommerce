import React, { useEffect, useState } from "react";
import Jacket from "../assets/images/jacket-1.jpg";
import { MdDeleteForever } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import {
  cartItem,
  getUserCartDetailsAsync,
  loading,
  removeCartItemAsync,
  updateCartItemAsync,
} from "../slice/cart/cartSlice";
import { useNavigate } from "react-router";
import {
  buyNow,
  getShippingAddressAsync,
} from "../slice/checkout/checkoutSlice";
import { userToken } from "../slice/auth/authSlice";

const Cart = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loader = useSelector(loading);
  const token = useSelector(userToken);

  const cartItems = useSelector((state) => {
    // if (!loader) {
    return state.cart.cartItems;
    // }
  });
  useEffect(() => {
    dispatch(getUserCartDetailsAsync());
  }, []);

  //
  const totalAmount = cartItems?.reduce(
    (amount, item) => item.product.price * item.quantity + amount,
    0
  );

  const handleRemoveItem = (id) => {
    dispatch(removeCartItemAsync(id));
  };

  const decreaseQuantity = (item) => {
    if (item.quantity > 1) {
      // if (!loader) {
      dispatch(
        updateCartItemAsync({
          id: item._id,
          newData: {
            quantity: item.quantity - 1,
          },
        })
      ).then(() => dispatch(getUserCartDetailsAsync()));
      // }
    }
  };

  const increaseQuantity = (item) => {
    if (item.quantity > 0) {
      // if (!loader) {
      dispatch(
        updateCartItemAsync({
          id: item._id,
          newData: {
            quantity: item.quantity + 1,
          },
        })
      ).then(() => dispatch(getUserCartDetailsAsync()));
      // }
    }
  };

  return (
    <>
      {token ? (
        <div>
          {cartItems?.length > 0 ? (
            <div className="font-poppins  max-w-5xl mt-12 m-auto">
              <div className="flex justify-between max-md:flex-col gap-5 p-4">
                <div className="min-w-[70%]">
                  <div>
                    <h1>Cart</h1>
                  </div>

                  <div className="mt-12 border p-6 rounded-2xl">
                    <div className="flex justify-between mb-7">
                      <div>Product</div>
                      <div className="flex justify-evenly w-[30%] max-sm:justify-end">
                        <div>Price</div>
                        <div className="max-sm:hidden">Quantity</div>

                        <div className="max-sm:hidden">Remove</div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-4">
                      {cartItems.map((item) => {
                        return (
                          <div className="flex justify-between items-center max-sm:block">
                            <div className="flex max-sm:justify-between">
                              <div className="flex items-center">
                                <div>
                                  <img
                                    className="h-[100px]"
                                    src={item.product.image[0].public_url}
                                    alt=""
                                  />
                                </div>

                                <div>
                                  <p>{item.product.brand}</p>
                                  <h2>{item.product.title}</h2>
                                </div>
                              </div>
                              <div className="self-center">
                                <p className="hidden max-sm:block">
                                  {item.product.price}
                                </p>
                              </div>
                            </div>
                            <div className="flex justify-evenly gap-2 w-[30%] max-sm:mt-3">
                              <div className="max-sm:hidden">
                                {item.product.price}
                              </div>
                              <div className="flex gap-2"></div>

                              <div>
                                <button
                                  className="border text-white w-6 bg-slate-500 text-center rounded-md"
                                  onClick={() => decreaseQuantity(item)}
                                >
                                  -
                                </button>
                              </div>
                              <div>{item.quantity}</div>
                              <div>
                                <button
                                  className="border text-white w-6 bg-slate-500 text-center rounded-md"
                                  onClick={() => increaseQuantity(item)}
                                >
                                  +
                                </button>
                              </div>
                              <div
                                className="hover:cursor-pointer text-2xl"
                                onClick={() => handleRemoveItem(item._id)}
                              >
                                <MdDeleteForever />
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="border w-[27%] h-[300px] rounded-2xl p-6 max-md:w-full">
                  <div>
                    <h2 className="mb-3">Price Details</h2>
                    <div className="flex justify-between">
                      <p>Price({cartItems.length} item)</p>
                      <p>${totalAmount}</p>
                    </div>
                    <div className="flex justify-between">
                      <p>Discounts</p>
                      <p>$0</p>
                    </div>
                    <div className="flex justify-between">
                      <p>Coupons</p>
                      <p>$0</p>
                    </div>
                    <div className="flex justify-between">
                      <p>Delivery Charges</p>
                      <p>Free</p>
                    </div>
                  </div>
                  <div className="flex justify-between mt-5">
                    <p>Total Amount</p>
                    <p>{totalAmount}</p>
                  </div>
                  <div
                    onClick={() => {
                      dispatch(buyNow(cartItems));
                      navigate("/checkout");
                    }}
                    className="mt-5"
                  >
                    Place Order
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex justify-center mx-auto w-[50%] h-[70vh]">
              <div className="self-center">No items in Cart</div>
            </div>
          )}
        </div>
      ) : (
        <div>{navigate("/login")}</div>
      )}
    </>
  );
};

export default Cart;
