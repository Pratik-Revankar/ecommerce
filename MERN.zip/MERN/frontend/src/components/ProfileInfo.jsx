import React, { useEffect, useState } from "react";
import { FaBoxOpen } from "react-icons/fa";
import { FaAddressBook } from "react-icons/fa6";
import { Link, useNavigate } from "react-router-dom";
import Address from "./Address";
import { useDispatch, useSelector } from "react-redux";
import {
  getUserDetailsAsync,
  loader,
  updateUserDetailsAsync,
  user,
  userToken,
} from "../slice/auth/authSlice";
import { getShippingAddressAsync } from "../slice/checkout/checkoutSlice";

const ProfileInfo = ({ isChecked, setIsChecked }) => {
  const [edit, setEdit] = useState(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const userData = useSelector(user);
  const loading = useSelector(loader);
  const token = useSelector(userToken);
  const [updateUserData, setUpdateUserData] = useState({
    firstName: userData?.firstName,
    email: userData?.email,
  });

  const [form, setForm] = useState("profile");
  console.log(userData);

  useEffect(() => {
    if (!token) {
      navigate("/login");
    }
    dispatch(getUserDetailsAsync()).then(() => {
      dispatch(getShippingAddressAsync());
      if (!loading) {
        setUpdateUserData({
          firstName: userData.firstName,
          email: userData.email,
        });
      }
    });
  }, []);
  console.log(updateUserData);

  const handleEdit = () => {
    setEdit(!edit);
    setUpdateUserData({
      firstName: userData.firstName,
      email: userData.email,
    });
  };

  const handleUpdate = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    console.log(name, value);
    setUpdateUserData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    dispatch(updateUserDetailsAsync(updateUserData)).then(() =>
      dispatch(getUserDetailsAsync())
    );
    setEdit(!edit);
  };
  return (
    <div>
      {userData?.firstName && (
        <div className="flex justify-between mt-4 w-[95%] m-auto max-lg:block">
          <div className="w-[25%] max-lg:w-full">
            <div className="border p-3 mb-4 ">
              <p>Hello,</p>
              <h2> {userData.firstName}</h2>
            </div>
            <div className=" flex flex-col gap-4 border p-3 mb-4  ">
              <Link to="/orders">
                <div className="flex gap-2 hover:cursor-pointer">
                  <FaBoxOpen className="text-2xl" />
                  My Orders
                </div>
              </Link>
              <div className="flex gap-2">
                <FaAddressBook className="text-2xl" />
                Account Settings
              </div>
              <div className="ml-8">
                <div
                  className="mb-2 hover:cursor-pointer"
                  onClick={() => setForm("profile")}
                >
                  Profile Information
                </div>
                <div
                  className="hover:cursor-pointer"
                  onClick={() => setForm("address")}
                >
                  Manage Address
                </div>
              </div>
            </div>
          </div>
          {form === "profile" ? (
            <div className="w-[70%] border p-7 max-lg:w-full">
              <div className="flex justify-between">
                <h1 className="mb-2">Personal Information</h1>
                <p onClick={handleEdit}>{edit ? "Edit" : "Cancel"}</p>
              </div>
              <div className="flex gap-5 w-full mb-4 flex-wrap">
                <div className="relative w-[40%] max-xs:w-full max-lg:w-[45%] ">
                  <label
                    htmlFor="firstname"
                    className="absolute left-1 text-xs"
                  >
                    Firstname
                  </label>
                  <input
                    id="firstname"
                    name="firstName"
                    type="text"
                    value={edit ? userData.firstName : updateUserData.firstName}
                    disabled={edit}
                    className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                    onChange={(e) => handleUpdate(e)}
                  />
                </div>
                <div className="relative w-[40%] max-xs:w-full max-lg:w-[45%] ">
                  <label htmlFor="lastname" className="absolute left-1 text-xs">
                    Lastname
                  </label>
                  <input
                    id="lastname"
                    name="lastname"
                    type="text"
                    value={""}
                    disabled={edit}
                    className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                  />
                </div>
              </div>
              <h1 className="mb-2">Email Address</h1>
              <div className="relative w-[50%] mb-4 max-xs:w-full  max-lg:w-[70%] max-md:w-full ">
                <label htmlFor="email" className="absolute left-1 text-xs">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  disabled={edit}
                  value={edit ? userData.email : updateUserData.email}
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                  onChange={(e) => handleUpdate(e)}
                />
              </div>
              <h1 className="mb-2">Mobile Number</h1>
              <div className="relative w-[50%] mb-4 max-xs:w-full max-lg:w-[70%] max-md:w-full ">
                <label htmlFor="name" className="absolute left-1 text-xs">
                  Mobile
                </label>
                <input
                  id=""
                  name="name"
                  type="text"
                  value={""}
                  disabled={edit}
                  className="w-full h-[50px] border border-[#e0e0e0] text-sm outline-none pt-5 pr-3 pl-3 "
                />
              </div>
              <button onClick={handleSave}>{!edit ? "Save" : ""}</button>
            </div>
          ) : (
            <div className="w-[70%]">
              <Address isChecked={isChecked} setIsChecked={setIsChecked} />
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProfileInfo;
