import React from "react";
import CategoryCard from "./CategoryCard";

const NewArrivals = () => {
  return (
    <div className="w-full ">
      <div className="grid grid-cols-3 gap-4">
        <div>
          <h3>New Arrivals</h3>
          <div>
            <CategoryCard />
          </div>
        </div>
        <div>
          <h3>Trending</h3>
          <div>
            <CategoryCard />
          </div>
        </div>
        <div>
          <h3>Top Rated</h3>
          <div>
            <CategoryCard />
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewArrivals;
