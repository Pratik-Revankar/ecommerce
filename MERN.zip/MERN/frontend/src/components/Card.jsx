import React, { useEffect } from "react";
const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
import {
  getProductDetailsAsync,
  getProductsAsync,
  product,
} from "../slice/product/productSlice";
import { LuHeart } from "react-icons/lu";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router";
import {
  addToWishlistAsync,
  getWishlistAsync,
  removeFromWishlistAsync,
  wishlist,
} from "../slice/wishlist/wishlistSlice";
const Card = () => {
  const products = useSelector(product);
  const wish = useSelector(wishlist);
  // console.log(products);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    dispatch(getWishlistAsync());
    console.log(wish);
  }, []);

  const heart = (id) => {
    if (
      wish?.findIndex((item) => {
        return item.product._id === id;
      }) < 0
    ) {
      return "none";
    } else {
      return "red";
    }
  };

  const handleWishlist = (id) => {
    console.log(id);
    if (
      wish?.findIndex((item) => {
        return item.product._id === id;
      }) < 0
    ) {
      dispatch(addToWishlistAsync({ product: id }));
    } else {
      wish.map((item) => {
        if (item.product._id === id) {
          dispatch(removeFromWishlistAsync(item._id));
        }
      });
    }
  };

  return (
    <>
      {products.length > 0 ? (
        <div className="bg-gray-100 w-full min-h-screen gap-4 grid grid-cols-3 max-lg:grid-cols-2  max-sm:grid-cols-2 max-xs:grid-cols-1 ">
          {products.map((product, i) => {
            return (
              <div
                key={i}
                className="w-60 min-h-[360px] p-2 mx-auto bg-white rounded-xl transform transition-all hover:-translate-y-2 duration 300 shadow-1g hover:shadow-2xl mt-4 mb-4 lg:mt-0 max-lg:w-[90%] max-md:w-[240px] max-sm:w-[220px] max-xs:w-[80%]"
                onClick={() => {
                  // console.log(product._id);
                  dispatch(getProductDetailsAsync(product._id));

                  navigate("/product/details");
                }}
              >
                <LuHeart
                  className="absolute right-2 text-2xl  hover:cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation(), handleWishlist(product._id);
                  }}
                  fill={heart(product._id)}
                  stroke="grey"
                />

                {/* </div> */}
                <img
                  src={product.image[0].public_url}
                  alt=""
                  className="h-40 object-cover rounded-xl m-auto"
                />
                <div className="p-2 h-[150px]">
                  <p className="font-bold text-xs mb-2"> {product.brand}</p>
                  <h2 className="font-bold text-sm mb-2"> {product.title}</h2>
                  <span className="text-lg font-semibold">
                    ${product.price}
                  </span>

                  <div className="flex items-center gap-2">
                    <span className="text-sm line-through opacity-75">
                      ${product.price}
                    </span>
                    <span className="font-bold text-sm p-2bg-yellow-300 rounded-5-2x1text-gray-600">
                      Save 10%
                    </span>
                  </div>

                  <div className="flex items-center st-2 gap-1">
                    <img src="images/star.png" alt="" className="w-5" />
                    <img src="images/star.png" alt="" className="w-5" />
                    <img src="images/star.png" alt="" className="w-5" />
                    <img src="images/star.png" alt="" className="w-5" />
                    <img src="images/star.png" alt="" className="w-5" />
                    <p className="font-bold text-xs text-gray-700">
                      Best Ratings
                    </p>
                  </div>

                  {/* <p className="text-sm text-gray-600 mt-2 mb-2">
                  Beautiful Animated Card Design Using Tailwind CSS. Subscribe
                  to My Youtube Channel for more...
                </p> */}
                </div>
                <div className="flex items-center justify-center gap-2 mb-3">
                  <button className="px-3 py-1 rounded-ig bg-blue-408 hover:bg-blue-500 font-semibold">
                    Buy Now
                  </button>
                  <button className="px-3 py-1 rounded-Igbg-gray-300hover:bg-gray-500">
                    <img
                      src="images/shopping-cart.png"
                      alt=""
                      className="w-6"
                    />
                  </button>
                  <button className="px-3 py-1 rounded-1gbg-gray-300hover:bg-gray-500">
                    <img src="images/love.png" alt="" className="w-6" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-gray-100 min-h-screen text-center ">
          <p className="mt-7">No Products Found</p>
        </div>
      )}
    </>
  );
};

export default Card;
