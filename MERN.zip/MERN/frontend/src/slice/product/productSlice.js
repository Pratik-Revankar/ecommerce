import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  getBrandsByCategory,
  getProductDetails,
  getProducts,
  getProductsByBrand,
  getProductsByCategory,
} from "./productAPI";

export const getProductsAsync = createAsyncThunk(
  "product/getProducts",
  async ({ keyword, currentPage, price, category, brand }) => {
    try {
      const data = await getProducts(
        category,
        brand,
        keyword,
        price,
        currentPage
      );
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const getProductsByCategoryAsync = createAsyncThunk(
  "product/byCategory",
  async (category) => {
    try {
      const data = await getProductsByCategory(category);
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const getProductsByBrandAsync = createAsyncThunk(
  "product/byBrand",
  async ({ category, brand }) => {
    try {
      const data = await getProductsByBrand({ category, brand });
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const getBrandsByCategoryAsync = createAsyncThunk(
  "product/category/brands",
  async (category) => {
    try {
      const data = await getBrandsByCategory(category);
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const getProductDetailsAsync = createAsyncThunk(
  "product/getDetails",
  async (id) => {
    try {
      const data = await getProductDetails(id);
      return data;
    } catch (error) {
      throw error;
    }
  }
);

const productSlice = createSlice({
  name: "product",
  initialState: {
    loading: false,
    products: [],
    brands: [],
    productDetails: [],
    currentOrder: [],
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getProductsAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getProductsAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.products = action.payload.product;
      })
      .addCase(getProductsByCategoryAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getProductsByCategoryAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.products = action.payload.product;
      })
      .addCase(getProductsByBrandAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getProductsByBrandAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.products = action.payload.product;
      })
      .addCase(getBrandsByCategoryAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.brands = action.payload.brands;
      })
      .addCase(getProductDetailsAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getProductDetailsAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.productDetails = action.payload.product;
        // console.log(state.productDetails);
      });
  },
});

export const productDetails = (state) => state.product.productDetails;
export const product = (state) => state.product.products;
export const loading = (state) => state.product.loading;
export const brand = (state) => state.product.brands;

export default productSlice.reducer;
