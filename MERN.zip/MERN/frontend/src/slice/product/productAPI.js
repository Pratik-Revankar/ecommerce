import { base_url } from "../../utils/baseUrl";

export const getProducts = async (
  category = "",
  brand = "",
  keyword = "",
  price = [0, 25000],
  currentPage = 1
) => {
  let link = `${base_url}product?keyword=${keyword}&page=${currentPage}&price[gte]=${price[0]}&price[lte]=${price[1]}`;

  if (category) {
    link = `${base_url}product?keyword=${keyword}&page=${currentPage}&price[gte]=${price[0]}&price[lte]=${price[1]}&category=${category}&brand=${brand}`;
  }
  // console.log(link);
  const response = await fetch(link);
  const data = await response.json();
  return data;
};

export const getProductsByCategory = async (category) => {
  // console.log(category);
  let link = `${base_url}product?category=${category}`;
  // console.log(link);

  const response = await fetch(link);
  // console.log(response);
  const data = await response.json();
  // console.log(data);
  return data;
};
export const getProductsByBrand = async ({ category, brand }) => {
  // console.log(brand);
  let link = `${base_url}product?category=${category}&brand=${brand}`;
  // console.log(link);
  const response = await fetch(link);

  const data = await response.json();

  return data;
};

export const getBrandsByCategory = async (category) => {
  let link = `${base_url}product/brands?category=${category}`;
  const response = await fetch(link);
  const data = await response.json();
  return data;
};

export const getProductDetails = async (id) => {
  let link = `${base_url}product/${id}`;
  const response = await fetch(link);
  const data = await response.json();
  return data;
};
