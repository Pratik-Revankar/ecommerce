import axios from "axios";
import { base_url } from "../../utils/baseUrl";

export const register = async (userData) => {
  const response = await fetch(`${base_url}user/register`, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(userData),
  });
  const data = await response.json();
  return data;
};

export const login = async (userData) => {
  // const response = await axios.post(`${base_url}user/login`, userData);
  // return response;
  console.log(userData);
  const response = await fetch(`${base_url}user/login`, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(userData),
  });
  const data = await response.json();
  return data;
};

export const logout = async () => {
  const response = await fetch(`${base_url}user/logout`, {
    method: "GET",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();
  return data;
};

export const getUserDetails = async () => {
  const response = await fetch(`${base_url}user/me`, {
    method: "GET",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();
  return data;
};

export const updateUserDetails = async (userData) => {
  const response = await fetch(`${base_url}user/update/profile`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(userData),
  });
  const data = await response.json();
  return data;
};
