import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  getUserDetails,
  login,
  logout,
  register,
  updateUserDetails,
} from "./authAPI";

export const createUserAsync = createAsyncThunk(
  "user/register",
  async (userData) => {
    try {
      return await register(userData);
    } catch (error) {
      throw error;
    }
  }
);

export const loginAsync = createAsyncThunk("user/login", async (userData) => {
  try {
    return await login(userData);
  } catch (error) {
    throw error;
  }
});

export const logoutAsync = createAsyncThunk("user/logout", async (userData) => {
  try {
    return await logout();
  } catch (error) {
    throw error;
  }
});

export const getUserDetailsAsync = createAsyncThunk(
  "user/updateDetails",
  async () => {
    try {
      return await getUserDetails();
    } catch (error) {
      throw error;
    }
  }
);

export const updateUserDetailsAsync = createAsyncThunk(
  "user/details",
  async (userData) => {
    try {
      return await updateUserDetails(userData);
    } catch (error) {
      throw error;
    }
  }
);

const authSlice = createSlice({
  name: "user",
  initialState: {
    loggedInUserToken: null, // this should only contain user identity => 'id'/'role'
    loading: false,
    error: null,
    userChecked: false,
    mailSent: false,
    passwordReset: false,
    message: "",
    userDetails: {},
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getUserDetailsAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getUserDetailsAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.userDetails = action.payload.user;
      })
      .addCase(createUserAsync.pending, (state) => {
        state.loading = true;
        state.message = "";
      })
      .addCase(createUserAsync.fulfilled, (state, action) => {
        state.loading = false;
        if (action.payload.sccess) {
          state.message = "";
          state.loggedInUserToken = action.payload.token;
        } else {
          state.message = action.payload.message;
        }
      })
      .addCase(loginAsync.pending, (state) => {
        state.loading = true;
        state.message = "";
      })
      .addCase(loginAsync.fulfilled, (state, action) => {
        state.loading = false;
        console.log(action.payload);
        if (action.payload.success) {
          state.message = "";
          state.loggedInUserToken = action.payload.success;
          state.userDetails = action.payload.user;
        } else {
          state.message = action.payload.message;
        }
      })
      .addCase(logoutAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(logoutAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.loggedInUserToken = null;
        state.userDetails = {};
      });
  },
});

export const message = (state) => state.auth.message;
export const user = (state) => state.auth.userDetails;
export const loader = (state) => state.auth.loading;
export const userToken = (state) => state.auth.loggedInUserToken;

export default authSlice.reducer;
