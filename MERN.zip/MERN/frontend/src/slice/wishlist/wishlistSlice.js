import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { addToWishlist, getWishlist, removeFromWishlist } from "./wishlistAPI";

export const getWishlistAsync = createAsyncThunk("wishlist/get", async () => {
  try {
    const data = await getWishlist();
    return data;
  } catch (error) {
    throw error;
  }
});
export const addToWishlistAsync = createAsyncThunk(
  "wishlist/add",
  async (id) => {
    try {
      const data = await addToWishlist(id);
      return data;
    } catch (error) {
      throw error;
    }
  }
);
export const removeFromWishlistAsync = createAsyncThunk(
  "wishlist/remove",
  async (id) => {
    console.log(id);
    try {
      const data = await removeFromWishlist(id);
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const wishlistSlice = createSlice({
  name: "wishlist",
  initialState: {
    wishlist: [],
    loading: false,
    error: "",
  },

  extraReducers: (builder) => {
    builder
      .addCase(getWishlistAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getWishlistAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.wishlist = action.payload.list;
      })
      .addCase(addToWishlistAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(addToWishlistAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.wishlist.push(action.payload.item);
      })
      .addCase(removeFromWishlistAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(removeFromWishlistAsync.fulfilled, (state, action) => {
        const index = state.wishlist.findIndex((item) => {
          return item._id === action.payload.list._id;
        });
        state.wishlist.splice(index, 1);
        state.loading = false;
      });
  },
});

export const wishlist = (state) => state.wishlist.wishlist;

export default wishlistSlice.reducer;
