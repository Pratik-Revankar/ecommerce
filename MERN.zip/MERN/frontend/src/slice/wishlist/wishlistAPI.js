import { base_url } from "../../utils/baseUrl";

export const getWishlist = async () => {
  const response = await fetch(`${base_url}wishlist`, {
    method: "GET",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();

  return data;
};

export const addToWishlist = async (item) => {
  const response = await fetch(`${base_url}wishlist/add`, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(item),
  });
  const data = await response.json();

  return data;
};

export const removeFromWishlist = async (id) => {
  console.log(id);
  const response = await fetch(`${base_url}wishlist/remove/${id}`, {
    method: "DELETE",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();

  return data;
};
