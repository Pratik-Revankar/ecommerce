import { base_url } from "../../utils/baseUrl";

export const getUserCartDetails = async () => {
  const response = await fetch(`${base_url}cart/details`, {
    method: "GET",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();

  return data;
};

export const addCartItem = async (item) => {
  const response = await fetch(`${base_url}cart/add`, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(item),
  });
  const data = await response.json();

  return data;
};

export const removeCartItem = async (id) => {
  const response = await fetch(`${base_url}cart/remove/${id}`, {
    method: "DELETE",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();

  return data;
};

export const updateCartItem = async ({ id, newData }) => {
  // console.log(newData);
  const response = await fetch(`${base_url}cart/update/${id}`, {
    method: "PATCH",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(newData),
  });
  const data = await response.json();

  return data;
};
