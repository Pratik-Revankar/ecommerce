import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  addCartItem,
  getUserCartDetails,
  removeCartItem,
  updateCartItem,
} from "./cartAPI";

export const getUserCartDetailsAsync = createAsyncThunk(
  "cart/getCartDetails",
  async () => {
    try {
      const data = await getUserCartDetails();
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const addCartItemAsync = createAsyncThunk(
  "cart/addItem",
  async (item) => {
    try {
      const data = await addCartItem(item);
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const removeCartItemAsync = createAsyncThunk(
  "cart/removeItem",
  async (id) => {
    try {
      const data = await removeCartItem(id);
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const updateCartItemAsync = createAsyncThunk(
  "cart/updateItem",
  async ({ id, newData }) => {
    try {
      const data = await updateCartItem({ id, newData });
      return data;
    } catch (error) {
      throw error;
    }
  }
);

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    cartItems: [],
    loading: false,
    error: "",
  },
  extraReducers: (builder) => {
    builder
      .addCase(getUserCartDetailsAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getUserCartDetailsAsync.fulfilled, (state, action) => {
        state.cartItems = action.payload.cartDetails;
        state.loading = false;
      })
      .addCase(addCartItemAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(addCartItemAsync.fulfilled, (state, action) => {
        state.cartItems.push(action.payload.cart);
        state.loading = false;
      })
      .addCase(updateCartItemAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(updateCartItemAsync.fulfilled, (state, action) => {
        state.cartItems.forEach((item) => {
          if (item._id === action.payload.cartItem._id) {
            console.log(item._id, action.payload.cartItem._id);
            item.quantity = action.payload.cartItem.quantity;
          }
        });
        state.loading = false;
      })

      .addCase(removeCartItemAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(removeCartItemAsync.fulfilled, (state, action) => {
        const index = state.cartItems.findIndex((item) => {
          return item._id === action.payload.cartItem._id;
        });
        state.cartItems.splice(index, 1);
        state.loading = false;
      });
  },
});

export const cartItem = (state) => state.cart.cartItems;

export const loading = (state) => state.cart.loading;

export default cartSlice.reducer;
