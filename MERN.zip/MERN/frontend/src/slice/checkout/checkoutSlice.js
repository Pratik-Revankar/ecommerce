import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  addShippingAddress,
  editShippingAddress,
  getShippingAddress,
  myOrders,
  newOrder,
} from "./checkoutAPI";

export const getShippingAddressAsync = createAsyncThunk(
  "checkout/contact",
  async () => {
    try {
      const data = await getShippingAddress();
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const addShippingAddressAsync = createAsyncThunk(
  "checkout/newContact",
  async (details) => {
    console.log(details);
    try {
      const data = await addShippingAddress(details);
      return data;
    } catch (error) {
      throw error;
    }
  }
);
export const editShippingAddressAsync = createAsyncThunk(
  "checkout/editContact",
  async ({ id, details }) => {
    // console.log(details);
    try {
      const data = await editShippingAddress({ id, details });
      console.log(data);
      return data;
    } catch (error) {
      throw error;
    }
  }
);

export const newOrderAsync = createAsyncThunk(
  "checkout/newOrder",
  async (details) => {
    try {
      const data = await newOrder(details);
      return data;
    } catch (error) {
      throw error;
    }
  }
);
export const myOrdersAsync = createAsyncThunk("checkout/orders", async () => {
  try {
    const data = await myOrders();
    return data;
  } catch (error) {
    throw error;
  }
});

const checkoutSlice = createSlice({
  name: "checkout",
  initialState: {
    shippingDetails: [],
    orderDetails: [],
    currentOrder: [],
    loading: false,
    error: "",
  },
  reducers: {
    buyNow(state, action) {
      console.log(action.payload);
      state.currentOrder = action.payload;
      console.log(state.currentOrder);
    },
  },

  extraReducers: (builder) => {
    builder
      .addCase(getShippingAddressAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(getShippingAddressAsync.fulfilled, (state, action) => {
        state.loading = false;
        state.shippingDetails = action.payload.address;
      })
      .addCase(newOrderAsync.pending, (state) => {
        state.loading = true;

        // state.orderDetails = action.payload;
      })
      .addCase(newOrderAsync.fulfilled, (state, action) => {
        state.loading = false;
        console.log(action.payload);
      })
      .addCase(editShippingAddressAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(editShippingAddressAsync.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(myOrdersAsync.pending, (state) => {
        state.loading = true;
      })
      .addCase(myOrdersAsync.fulfilled, (state, action) => {
        state.orderDetails = action.payload.orders;
      });
  },
});

export const { buyNow } = checkoutSlice.actions;
export const address = (state) => state.checkout.shippingDetails;
export const order = (state) => state.checkout.currentOrder;
export const orders = (state) => state.checkout.orderDetails;
export const loading = (state) => state.checkout.loading;
export default checkoutSlice.reducer;
