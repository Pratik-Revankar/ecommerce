import { base_url } from "../../utils/baseUrl";

export const getShippingAddress = async () => {
  const response = await fetch(`${base_url}contact/`, {
    method: "GET",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();

  return data;
};
export const myOrders = async () => {
  const response = await fetch(`${base_url}order/myOrders`, {
    method: "GET",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();

  return data;
};

export const addShippingAddress = async (details) => {
  const obj = { shippingInfo: details };
  const response = await fetch(`${base_url}contact/new`, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(obj),
  });
  const data = await response.json();
  return data;
};
export const editShippingAddress = async ({ id, details }) => {
  console.log({ id, details });
  const response = await fetch(`${base_url}contact/${id}`, {
    method: "PUT",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ shippingInfo: details }),
  });
  const data = await response.json();
  console.log(data);
  return data;
};

export const newOrder = async (details) => {
  const response = await fetch(`${base_url}order/new`, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(details),
  });
  const data = await response.json();
  return data;
};
