/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    screens: {
      xs: "475px",

      sm: "650px",
      // => @media (min-width: 640px) { ... }

      md: "768px",
      // => @media (min-width: 768px) { ... }

      lg: "890px",
      // => @media (min-width: 1024px) { ... }

      xl: "1000px",
      // => @media (min-width: 1280px) { ... }
    },
    extend: {
      fontFamily: {
        // poppins: ["Poppins", "sans-serif"],
        // Inter: ["Inter", "sans-serif"],
      },
    },
  },
  plugins: [require("tailwind-scrollbar")],
};
